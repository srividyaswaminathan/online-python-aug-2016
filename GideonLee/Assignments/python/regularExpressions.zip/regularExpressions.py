import re

#find the first email you see
str1 = 'purple alice@google.com, blah monkey bob@abc.com blah dishwasher'
match = re.search(r'[\w.-]+@[\w.-]+', str1)
if match:
	print match.group()

#find all of the emails in a string
str2 = 'purple alice@google.com, blah monkey bob@abc.com blah dishwasher'
match = re.findall(r'[\w.-]+@[\w.-]+', str2)
if match:
	print match #Don't need .group() because this is a list

#replace @google.com and @abc.com with @gmail.com and return a list of all the gmail accounts in the given string. 
str3 = 'purple alice@google.com, blah monkey bob@abc.com blah dishwasher'
str4 = re.sub(r'\@\w+', r'@gmail', str3)
match = re.findall(r'[\w.-]+@[\w.-]+', str4)
if match:
	print match

# read a file, take all the emails, retrieve them into a list, and convert them all to gmail. Print email out. 
print '\n'
f = open('file.txt', 'r')
match = re.findall(r'[\w.-]+@[\w.-]+', f.read())
for i in match: 
	print 'This search found: ' + i

print '\nNow convert to gmail\n'
for i in match: 
	replace = re.sub(r'\@\w+', r'@gmail', i)
	print replace
