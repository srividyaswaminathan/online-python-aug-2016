for x in xrange(1,1000, 2):
	print x