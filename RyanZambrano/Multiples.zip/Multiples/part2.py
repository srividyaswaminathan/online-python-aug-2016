for x in xrange(5,1000001, 5):
	print x